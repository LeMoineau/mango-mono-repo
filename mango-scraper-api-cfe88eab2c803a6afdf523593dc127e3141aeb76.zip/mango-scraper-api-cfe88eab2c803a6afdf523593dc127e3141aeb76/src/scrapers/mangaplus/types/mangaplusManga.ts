export interface MangaPlusManga {
  id: number;
  title: string;
  author: string;
  portraitThumbnail: string;
  views: number;
}
