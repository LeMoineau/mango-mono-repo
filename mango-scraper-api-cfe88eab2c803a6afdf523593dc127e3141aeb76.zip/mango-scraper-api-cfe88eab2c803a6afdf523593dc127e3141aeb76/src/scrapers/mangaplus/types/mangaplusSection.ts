import { MangaPlusCard } from "./mangaplusCard";

export interface MangaPlusSection {
  title: string;
  cards: MangaPlusCard[];
}
