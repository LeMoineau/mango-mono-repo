export interface IntersiteManga {}
