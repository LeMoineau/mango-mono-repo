export interface JsonObject {
  [key: string]: any;
}
