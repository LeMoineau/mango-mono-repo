import { describe } from "vitest";

describe("mangas-route", () => {});
